import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv('population_dataset.csv')

plt.figure(figsize=(6,4))
df['Age'].hist(bins=10)
plt.title('Age Distribution')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.savefig('age_histogram.png')
plt.show()

plt.figure(figsize=(5,4))
df['Gender'].value_counts().plot(kind='bar')
plt.title('Gender Distribution')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.savefig('gender_barchart.png')
plt.show()
